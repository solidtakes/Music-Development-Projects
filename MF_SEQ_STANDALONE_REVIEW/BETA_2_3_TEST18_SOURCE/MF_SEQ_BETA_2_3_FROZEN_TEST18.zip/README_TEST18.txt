MF SEQ Beta 2.2 TEST 18 — NOT HARDWARE VALIDATED
Built from accepted Beta 2.1 Test 17. Preserve it as rollback.

NEW
Hold E13 first + tap E1/E2/E3/E4: directly select edit bar 1/2/3/4.
Hold E16 first + tap E1: toggle Follow Playback ON/OFF.
Follow defaults OFF; when ON it changes page only at playback bar boundaries,
including shortened loop wrap. Manual bar selection pauses follow until the
next playback start; toggling follow resets the manual pause.
E1 first + twist E16 retains frozen page navigation.
E1 first + press/twist E13/E14/E15 remains frozen.

Note: follow uses Live clip.playing_position; verify on your system.
No Native Mode, color/brightness, CC1, or shared bank changes.
Test with disposable MIDI clip. Check order-sensitive modifiers, ties,
notes, parameter presets, 1/2/4 bar loops, page navigation and stop/restart.
