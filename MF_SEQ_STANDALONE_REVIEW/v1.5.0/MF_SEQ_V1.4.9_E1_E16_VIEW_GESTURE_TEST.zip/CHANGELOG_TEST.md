MF SEQ v1.4.9 — E1+E16 view gesture experimental standalone build
Base: MF_BANK2_SEQ_V1.4.8_STANDALONE_V1_STABILIZATION_TEST.zip

CHANGES
- Hold E1 + press E16: toggle Pitch/Velocity ring view (replaces next bar).
- Hold E1 + press E14: next bar (relocated from E16).
- Hold E1 + press E15: previous bar (unchanged).
- E1 double-click timer, pending taps, and double-click state removed.
- E1 single tap edits on button release immediately (NOT on initial press), preserving hold+press tie and push+turn behavior.
- Chord buttons consumed on release; no accidental note entry.
- CC mapping UNCHANGED: 48-63, push channel 11, rotary channel 12. Physical bank assignment must be verified.
- Four-bar maximum preserved. No cross-bank/shared files changed.

CHECKS
- Python syntax compilation: passed. ZIP contents: checked.
- Ableton and MIDI Fighter hardware: NOT TESTED.
- Test E1 tap, E1+E16, E1+E14/E15, tie, push+twist, release order, note entry on other steps, LED/playhead, bank switch.
- Does not address accumulated MIDI/LED performance backlog.
